<template>
  <h1>Início</h1>
</template>

<script>
export default {
  components: {
      name: 'Home'
  }
}
</script>